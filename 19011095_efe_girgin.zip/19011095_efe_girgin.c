#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Ogrenci { 
char ogrID[8];
char ad[30]; 
char soyad[30]; 
int puan; 
struct Ogrenci *next; 
struct Ogrenci *prev
}ogrenci;

typedef struct Yazar { 
int yazarID; 
char yazarAd[30]; 
char yazarSoyad[30]; 
struct Yazar *next
}yazar;

typedef struct KitapOrnek { 
char EtiketNo[20]; 
char Durum[8]; 
struct KitapOrnek *next 
}kitapOrnk;

typedef struct Kitap {
char kitapAd�[30]; 
char ISBN[13]; 
struct Kitap *next; 
struct KitapOrnek *head 
}kitap;

typedef struct KitapYazar{ 
char ISBN[13]; 
int YazarID
}kyazar;

typedef struct Tarih{ 
int gun:5; 
int ay:4; 
int yil:12
}tarih;

typedef struct KitapOdunc{ 
char EtiketNo[20]; 
char ogrID[8]; 
int islemTipi:1; 
struct Tarih islemTarihi
}kodunc;

kitap* otokitapekle(int * durum_sayisi, kitap * head){
	FILE *data;
 	kitap *sira,*deger,*eskisira,*kontrol_degeri;
 	
	int i,k=0,j,l=0,kredi,kontenjan;
 	
	char date[15],kitapAd�[30],char ISBN[13];;
 	
	data=fopen("ders.txt","r");
 	
	 if(!data){
 		printf("Ders eklenecek dosya bulunamadi\n");
 		return NULL;
	 }
	 
	else{
		 while(fscanf(data,"%s %s %d %d\n",kod,adi,&kredi,&kontenjan)==4){
	 		deger=(ders*)malloc(sizeof(ders));
	 		strcpy_s(deger->ders_adi,20,adi);
	 		strcpy_s(deger->ders_kodu,20,kod);
	 		deger->kredi=kredi;
	 		deger->kontenjan=kontenjan;
	 		deger->next=NULL;
	 		deger->ogrenci_sayisi=0;
	 		deger->kalan_kontenjan=kontenjan;
	 		if(head==NULL){
	 			head=deger;
	 			eskisira=head;
			 }
			 else{
				eskisira->next=deger;
				eskisira=deger;
				deger=NULL;
			 	
			 }
	 	
	 	}
	 }
	 return head;
}


ogrenci* find_student(ogrenci **head,int student_id){
	
	ogrenci* current=*head;
	
	while(current!=NULL){
		if(current->id==student_id){
			//printf("\n find_student():Student Found \n");
			return current;
		}
		
		current=current->next_student;
	}
	//printf("\n find_student():Student Not Found \n");
	return NULL;
}

int remove_student(STUDENT **head,STUDENT *student){
	ogrenci *current=*head;
	ogrenci *prev=NULL;
	
	int is_found=0;
	while(current!=NULL && !is_found){
		if(current->id==student->id){
			
			is_found=1;
			if(prev==NULL){
				*head=student->next_student;
			}else{
				ogrenci* tmp=ogrenci->next_student;
				prev->next_student=ogrenci->next_student;
				tmp->prev_student=prev;
			}
			
			free(current);
			
		}else{
			
			prev=current;
			current=current->next_student;
		}
	}
	
	return 0;
}

int add_student(ogrenci **head,ogrenci *student){
  if(*head==NULL){
  	*head=student;
  	printf("\n Yeni ogrenci listenin basina eklendi \n");
    return 0;
  }else{
  	if(student_exist(*head,student)){
  		
  		printf("\n Var olan ogrenci tekrar eklenemez\n");
  		
  		return 1;
  		
	}else{
		  	
	
  	
  	  ogrenci *current;
      ogrenci *next;
	  ogrenci *prev;
		
      current = *head;
      next = current->next_student;
	  prev = current->prev_student;
	  
	  
      while (current != NULL && next!=NULL){

        if (student->id > current->id && student->id < next->id){
        	
          current->next_student = student;
          student->prev_student=current;
          
          student->next_student = next;
          next->prev_student=student;
          
          return 0;
          
        }

        current = next;
        next = next->next_student;
      }

      if (next == NULL){
        if (current->id < student->id){
          
		  current->next_student = ogrenci;
		  student->prev_student=current;
		  
		  printf("\n Yeni ogrenci listenin sonuna eklendi \n");
		  return 0;
        }else{

          ogrenci *tmp = *head;
          *head = ogrenci;
          ogrenci->next_student = tmp;
          printf("\n Yeni ogrenci listenin basina eklendi \n");
          return 0;
        }
      }

      //printf("\n Log:add new student to list\n");

      return 0;
      
    }  
  }
  return 0;
}

void print_student(STUDENT* head){
  ogrenci *tmp = head;
  while(tmp != NULL){
    printf("\n%d, %s, %s \n",tmp->id,tmp->name,tmp->surname);
    tmp = tmp->next_student;
    
  }	
  //free(head);
  
}
